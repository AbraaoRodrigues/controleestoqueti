<?php
include '../includes/conexao.php';

$nome = $_POST['nome'];
$descricao = $_POST['descricao'];
$categoria_id = $_POST['categoria_id'];

$stmt = $conn->prepare("INSERT INTO itens (nome, descricao, categoria_id) VALUES (?, ?, ?)");
$stmt->bind_param("ssi", $nome, $descricao, $categoria_id);
$stmt->execute();

header('Location: lista.php');
exit();
?>