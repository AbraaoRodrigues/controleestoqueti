<?php
include '../includes/conexao.php';

$result = $conn->query("SELECT MAX(id) AS max_id FROM itens");
$proximo_id = ($result->fetch_assoc()['max_id'] ?? 0) + 1;
?>

<form action="salvar.php" method="POST">
  <div>
    <label>Código (automático):</label>
    <input type="text" value="<?= $proximo_id ?>" readonly class="form-control">
  </div>
  <div>
    <label>Nome:</label>
    <input type="text" name="nome" required class="form-control">
  </div>
  <div>
    <label>Descrição:</label>
    <textarea name="descricao" class="form-control"></textarea>
  </div>
  <div>
    <label>Categoria (ID):</label>
    <input type="number" name="categoria_id" required class="form-control">
  </div>
  <button type="submit">Salvar</button>
</form>