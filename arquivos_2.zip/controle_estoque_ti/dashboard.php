<?php include 'includes/header.php'; ?>
<h1>Bem-vindo ao Controle de Estoque</h1>