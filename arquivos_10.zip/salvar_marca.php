<?php
include '../includes/init.php';
$nome = trim($_POST['nome']);
if ($nome) {
  $stmt = $conn->prepare("INSERT INTO marcas (nome) VALUES (?)");
  $stmt->bind_param("s", $nome);
  $stmt->execute();
}
header('Location: ../itens/cadastro.php');
