<?php
include '../includes/init.php';
$marcas = $conn->query("SELECT id, nome FROM marcas ORDER BY nome");
?>

<div class="mb-3">
  <label for="marca_id">Marca</label>
  <div class="input-group">
    <select name="marca_id" id="marca_id" class="form-select" required>
      <option value="">Selecione a marca</option>
      <?php while($m = $marcas->fetch_assoc()): ?>
        <option value="<?= $m['id'] ?>"><?= $m['nome'] ?></option>
      <?php endwhile; ?>
    </select>
    <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#modalMarca">+</button>
  </div>
</div>

<div class="mb-3">
  <label for="modelo_id">Modelo</label>
  <div class="input-group">
    <select name="modelo_id" id="modelo_id" class="form-select" required>
      <option value="">Selecione a marca primeiro</option>
    </select>
    <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#modalModelo">+</button>
  </div>
</div>

<script>
document.getElementById('marca_id').addEventListener('change', function() {
  let marcaId = this.value;
  fetch('../modelos/get_modelos.php?marca_id=' + marcaId)
    .then(res => res.json())
    .then(data => {
      let select = document.getElementById('modelo_id');
      select.innerHTML = '<option value="">Selecione o modelo</option>';
      data.forEach(function(modelo) {
        let opt = document.createElement('option');
        opt.value = modelo.id;
        opt.textContent = modelo.nome;
        select.appendChild(opt);
      });
    });
});
</script>

<?php include 'modais_marcas_modelos.php'; ?>
