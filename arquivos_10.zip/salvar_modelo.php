<?php
include '../includes/init.php';
$nome = trim($_POST['nome']);
$marca_id = intval($_POST['marca_id']);
if ($nome && $marca_id) {
  $stmt = $conn->prepare("INSERT INTO modelos (marca_id, nome) VALUES (?, ?)");
  $stmt->bind_param("is", $marca_id, $nome);
  $stmt->execute();
}
header('Location: ../itens/cadastro.php');
