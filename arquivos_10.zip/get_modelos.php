<?php
include '../../includes/conexao.php';
$marca_id = intval($_GET['marca_id']);
$result = $conn->query("SELECT id, nome FROM modelos WHERE marca_id = $marca_id ORDER BY nome");
$modelos = [];
while($row = $result->fetch_assoc()) {
    $modelos[] = $row;
}
header('Content-Type: application/json');
echo json_encode($modelos);
