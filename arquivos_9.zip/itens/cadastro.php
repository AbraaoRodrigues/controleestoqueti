<?php
include '../includes/conexao.php';
$categorias = $conn->query("SELECT * FROM categorias ORDER BY nome");
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<div class="container mt-4">
  <h4>Cadastro de Item</h4>
  <form method="POST" action="salvar.php">
    <div class="mb-3">
      <label>Nome</label>
      <input type="text" name="nome" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Categoria</label>
      <div class="input-group">
        <select name="categoria_id" class="form-select" required>
          <option value="">Selecione...</option>
          <?php while($cat = $categorias->fetch_assoc()): ?>
            <option value="<?= $cat['id'] ?>"><?= $cat['nome'] ?></option>
          <?php endwhile; ?>
        </select>
        <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#modalCategoria">Cadastrar nova</button>
      </div>
    </div>
    <button type="submit" class="btn btn-success">Salvar</button>
  </form>
</div>

<?php include 'categorias_modal.php'; ?>