<?php
include '../includes/conexao.php';
$nome = $_POST['nome'];
$categoria_id = $_POST['categoria_id'];
$conn->query("INSERT INTO itens (nome, categoria_id) VALUES ('$nome', $categoria_id)");
header('Location: cadastro.php');
exit();
?>