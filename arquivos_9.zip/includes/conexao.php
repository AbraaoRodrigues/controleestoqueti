<?php
$conn = new mysqli('localhost', 'root', '', 'estoque_ti');
?>