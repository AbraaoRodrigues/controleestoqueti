<?php
include '../includes/init.php';
$marca_id = intval($_GET['marca_id']);
$modelos = $conn->query("SELECT id, nome FROM modelos WHERE marca_id = $marca_id ORDER BY nome");
echo json_encode($modelos->fetch_all(MYSQLI_ASSOC));
