<?php
include '../includes/init.php';

$nome = trim($_POST['nome']);
$marca_id = intval($_POST['marca_id']);

$jaExiste = $conn->prepare("SELECT id FROM modelos WHERE nome = ? AND marca_id = ?");
$jaExiste->bind_param("si", $nome, $marca_id);
$jaExiste->execute();
$jaExiste->store_result();

if ($jaExiste->num_rows === 0 && $nome && $marca_id) {
  $stmt = $conn->prepare("INSERT INTO modelos (marca_id, nome) VALUES (?, ?)");
  $stmt->bind_param("is", $marca_id, $nome);
  $stmt->execute();
  echo "<script>window.opener.postMessage({modeloId: {$stmt->insert_id}}, '*'); window.close();</script>";
} else {
  echo "<script>alert('Modelo já existente.'); window.close();</script>";
}
exit();
